"""Generate evaluation reports."""
def generate_report(results):
    """Return a simple text report (stub)."""
    return str(results)
