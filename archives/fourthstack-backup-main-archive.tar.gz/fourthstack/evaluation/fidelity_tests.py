"""Fidelity tests for synthetic data evaluation."""
def compare_distributions(real, synthetic):
    """Return a stub score representing distribution similarity."""
    return 1.0
