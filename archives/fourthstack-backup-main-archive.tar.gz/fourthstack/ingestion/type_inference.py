"""Type inference utilities for ingestion."""
def infer_types(records):
    """Stub: infer column types from sample records."""
    return {"column": "string"}
