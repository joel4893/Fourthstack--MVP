"""Transformer block utilities (stub)."""
def transformer_block(x, params=None):
    """Apply a transformer-like block to input x (stub)."""
    return x
