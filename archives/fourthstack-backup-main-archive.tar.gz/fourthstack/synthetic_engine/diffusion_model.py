"""Stub diffusion model for synthetic data generation."""
class DiffusionModel:
    def __init__(self, config=None):
        self.config = config or {}

    def sample(self, n_steps=10):
        """Return stub samples."""
        return []
