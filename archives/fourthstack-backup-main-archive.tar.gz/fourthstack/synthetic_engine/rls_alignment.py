"""Reinforcement learning + alignment utilities (stub)."""
def align_with_rl(policy, reward_fn):
    """Stub: perform RL alignment; returns improved policy."""
    return policy
