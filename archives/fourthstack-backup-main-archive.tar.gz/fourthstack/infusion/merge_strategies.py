"""Merge strategies for infusing synthetic data into real datasets."""
def simple_merge(real, synthetic):
    """Return combined list with synthetic appended (stub)."""
    return real + synthetic
