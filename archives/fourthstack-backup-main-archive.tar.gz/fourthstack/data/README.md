# Local dummy data directory

This folder is a local-only dummy directory used for development and testing.

- `raw/`, `processed/`, `synthetic/`, etc. should be created here when you need local copies of S3 prefixes.
- This directory is not intended for production data and can be ignored in deployment.

Add small sample files under subfolders when you need to run local pipelines.
