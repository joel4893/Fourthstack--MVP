# Fourthstack (module) README

This folder contains submodules for ingestion, preprocessing, synthetic engines, infusion, evaluation, and configuration files.
